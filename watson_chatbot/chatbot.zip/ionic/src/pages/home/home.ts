import { Component, Renderer, NgZone } from "@angular/core";
import { NavController, ModalController } from "ionic-angular";
import { DataStore } from "../../app/dataStore";
import { ChatPage } from "../chat/chat";

@Component({
  selector: "page-home",
  templateUrl: "home.html"
})
export class HomePage {
  constructor(public navCtrl: NavController, public dataStore: DataStore) { }

  home_Button_8092_clickHandler() {
    this.navCtrl.push(ChatPage, {
      data: { "a": "a" }
    });
  }
}
