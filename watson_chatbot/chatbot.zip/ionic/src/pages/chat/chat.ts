import { Component, Renderer, NgZone } from '@angular/core';
import { NavController, ModalController, LoadingController } from 'ionic-angular';
import { DataStore } from '../../app/dataStore';
import WatsonChat from "../../componentScripts/chat";
import { Platform } from "ionic-angular";

@Component({
  selector: 'page-chat',
  templateUrl: 'chat.html'
})
export class ChatPage {

  constructor(public navCtrl: NavController, public dataStore: DataStore, renderer: Renderer, private zone: NgZone, public platform: Platform) {
    this.watsonChat.init(this.url, this.iam_apikey, this.workspaceId, eval('this.shouldSendWatsonAssistantAnalytics'));
    platform.ready().then(() => { this.message() });

  }

  messages = [];
  input: any;
  watsonChat = new WatsonChat();

  message() {
    this.watsonChat.sendMessage(this.messages, this.input, (err, msgs) => { this.zone.run(() => { this.messages = msgs; }); }); this.input = '';
  }

  url = null;
  iam_apikey = null;
  workspaceId = null;

}