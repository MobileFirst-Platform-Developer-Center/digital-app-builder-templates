/// <reference path="../plugins/cordova-plugin-mfp-liveupdate/typings/liveupdate.d.ts"/>
/// <reference path="../plugins/cordova-plugin-mfp/typings/worklight.d.ts" />
