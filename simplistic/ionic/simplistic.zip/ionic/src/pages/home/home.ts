import { Component, Renderer, NgZone } from '@angular/core';
import { App, NavController, ModalController } from 'ionic-angular';
import { DataStore } from '../../app/dataStore';
import { ListPage } from '../list/list';
import { Empty1Page } from '../empty1/empty1';
import { Empty2Page } from '../empty2/empty2';
import { ChatBotPage } from '../chatBot/chatBot';
import { LoginPage } from '../login/login';

@Component({
  selector: 'page-home',
  templateUrl: 'home.html'
})
export class HomePage {
  constructor(
    public navCtrl: NavController,
    public renderer: Renderer,
    public dataStore: DataStore,
    public appCtrl: App
  ) { }

  hubcards: {
    title: string;
    desc: string;
    navigatePage: object;
    icon: string;
  }[] = [
      {
        title: 'list',
        desc: 'List your items here',
        navigatePage: ListPage,
        icon: 'build/assets/imgs/no-image.png'
      },
      {
        title: 'Chat Bot',
        desc: 'Chat with bot here',
        navigatePage: ChatBotPage,
        icon: 'build/assets/imgs/no-image.png'
      },
      {
        title: 'Empty',
        desc: 'Design your desired page here',
        navigatePage: Empty1Page,
        icon: 'build/assets/imgs/no-image.png'
      },
      {
        title: 'Empty',
        desc: 'Design your desired page here',
        navigatePage: Empty2Page,
        icon: 'build/assets/imgs/no-image.png'
      }
    ];

  // use it for navigation in hub pages
  navigateFromHubCard(page) {
    this.navCtrl.push(page, {});
  }

  username = (this.dataStore as any).username || 'User';
  logout() {
    var self = this;
    WLAuthorizationManager.logout('UserLogin').then(
      () => {
        WL.Logger.debug('logout onSuccess');
        self.appCtrl.getRootNav().push(LoginPage);
      },
      response => {
        WL.Logger.error('logout onFailure: ' + JSON.stringify(response));
      }
    );
  }
}
