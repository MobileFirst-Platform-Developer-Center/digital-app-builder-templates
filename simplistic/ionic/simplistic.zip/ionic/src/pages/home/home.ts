import { Component, Renderer, NgZone } from '@angular/core';
import { NavController, ModalController } from 'ionic-angular';
import { DataStore } from '../../app/dataStore';
import { Empty1Page } from '../empty1/empty1';
import { Empty2Page } from '../empty2/empty2';
import { ListPage } from '../list/list';
import { ChatPage } from '../chat/chat';

@Component({
  selector: 'page-home',
  templateUrl: 'home.html'
})
export class HomePage {
  constructor(
    public navCtrl: NavController,
    public renderer: Renderer,
    public dataStore: DataStore
  ) {}

  hubcards: {
    title: string;
    desc: string;
    navigatePage: object;
    icon: string;
  }[] = [
    {
      title: 'List',
      desc: 'List your items here',
      navigatePage: ListPage,
      icon: 'build/assets/imgs/payslips.jpeg'
    },
    {
      title: 'ChatBot',
      desc: 'Chat with Bot here',
      navigatePage: ChatPage,
      icon: 'build/assets/imgs/compensation.jpeg'
    },
    {
      title: 'Empty',
      desc: 'Design your desired page here',
      navigatePage: Empty1Page,
      icon: 'build/assets/imgs/benefits.jpeg'
    },
    {
      title: 'Empty',
      desc: 'Design your desired page here',
      navigatePage: Empty2Page,
      icon: 'build/assets/imgs/docs.jpeg'
    }
  ];

  // use it for navigation in hub pages
  navigateFromHubCard(page) {
    this.navCtrl.push(page, {});
  }

  username = (this.dataStore as any).username || 'User';
}
