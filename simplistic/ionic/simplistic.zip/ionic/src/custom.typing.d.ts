/// <reference path="../plugins/cordova-plugin-mfp/typings/worklight.d.ts" />
