import { Component, Renderer, NgZone } from '@angular/core';
import {
  NavController,
  ModalController,
  NavParams,
  Platform
} from 'ionic-angular';
import { DataStore } from '../../app/dataStore';

@Component({
  selector: 'page-listdetails',
  templateUrl: 'listdetails.html'
})
export class ListdetailsPage {
  itemDetails = {};
  constructor(
    public navCtrl: NavController,
    public renderer: Renderer,
    public dataStore: DataStore,
    public navParams: NavParams,
    public platform: Platform
  ) {
    this.itemDetails = navParams.data.itemDetails;
  }
  viewPlatform: string = '';
  ionViewWillEnter() {
    if (this.platform.is('core')) {
      this.viewPlatform = 'web';
    } else {
      this.viewPlatform = 'mobile';
    }
  }

  handleButtonClick() {
    console.log('clicked');
  }

    ionViewDidLoad() {
        WL.Analytics.log({ fromPage: this.navCtrl.getPrevious(this.navCtrl.getActive()).name, toPage: this.navCtrl.getActive().name }, 'PageTransition ');
        WL.Analytics.send();
    }
}
