import { Component, Renderer, NgZone } from '@angular/core';
import { App, NavController, ModalController } from 'ionic-angular';
import { DataStore } from '../../app/dataStore';
import { ChatBotPage } from '../chatBot/chatBot';
import { Empty1Page } from '../empty1/empty1';
import { Empty2Page } from '../empty2/empty2';
import { ListPage } from '../list/list';
import { LoginPage } from '../login/login';

@Component({
  selector: 'page-home',
  templateUrl: 'home.html'
})
export class HomePage {
  constructor(
    public navCtrl: NavController,
    public renderer: Renderer,
    public dataStore: DataStore,
    public appCtrl: App
  ) { }

  hubcards: {
    title: string;
    desc: string;
    navigatePage: object;
    icon: string;
  }[] = [
      {
        title: 'List',
        desc: 'List your items here',
        navigatePage: ListPage,
        icon: '../../assets/imgs/no-image.png'
      },
      {
        title: 'ChatBot',
        desc: 'Chat with Bot here',
        navigatePage: ChatBotPage,
        icon: '../../assets/imgs/no-image.png'
      },
      {
        title: 'Empty',
        desc: 'Design your desired page here',
        navigatePage: Empty1Page,
        icon: '../../assets/imgs/no-image.png'
      },
      {
        title: 'Empty',
        desc: 'Design your desired page here',
        navigatePage: Empty2Page,
        icon: '../../assets/imgs/no-image.png'
      }
    ];

  // use it for navigation in hub pages
  navigateFromHubCard(page) {
    this.navCtrl.push(page, {});
  }

  username = (this.dataStore as any).username || 'USER';
  logout() {
    var self = this;
    WLAuthorizationManager.logout('UserLogin').then(
      () => {
        WL.Logger.debug('logout onSuccess');
        self.appCtrl.getRootNav().push(LoginPage);
      },
      response => {
        WL.Logger.error('logout onFailure: ' + JSON.stringify(response));
      }
    );
  }
}
