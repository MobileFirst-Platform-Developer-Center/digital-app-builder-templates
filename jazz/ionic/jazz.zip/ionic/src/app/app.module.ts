import { BrowserModule } from '@angular/platform-browser';
import { ErrorHandler, NgModule } from '@angular/core';
import { IonicApp, IonicErrorHandler, IonicModule } from 'ionic-angular';
import { DataStore } from './dataStore';
import { MyApp } from './app.component';
import { HomePage } from '../pages/home/home';
import { LiveUpdateProvider } from '../providers/live-update/live-update';
import { StatusBar } from '@ionic-native/status-bar';
import { SplashScreen } from '@ionic-native/splash-screen';
import { LoginPage } from "../pages/login/login";
import { ChatBotPage } from "../pages/chatBot/chatBot";
import { Empty1Page } from "../pages/empty1/empty1";
import { Empty2Page } from "../pages/empty2/empty2";
import { ListdetailsPage } from "../pages/listdetails/listdetails";
import { ListPage } from "../pages/list/list";

@NgModule({
  declarations: [
    MyApp,
    HomePage
  ,LoginPage,ChatBotPage,Empty1Page,Empty2Page,ListdetailsPage,ListPage],
  imports: [
    BrowserModule,
    IonicModule.forRoot(MyApp),
  ],
  bootstrap: [IonicApp],
  entryComponents: [
    MyApp,
    HomePage
  ,LoginPage,ChatBotPage,Empty1Page,Empty2Page,ListdetailsPage,ListPage],
  providers: [
    StatusBar,
    SplashScreen,
    DataStore,
    {provide: ErrorHandler, useClass: IonicErrorHandler},
    LiveUpdateProvider
  ]
})
export class AppModule {}
